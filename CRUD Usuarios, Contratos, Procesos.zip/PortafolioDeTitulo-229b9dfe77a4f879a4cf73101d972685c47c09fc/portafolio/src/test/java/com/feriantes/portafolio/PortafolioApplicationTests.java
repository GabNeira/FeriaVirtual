package com.feriantes.portafolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortafolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
